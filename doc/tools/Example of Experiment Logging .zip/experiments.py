import sys
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import seaborn as sns
import time
from tqdm import tqdm
from glob import glob
import json 


# add tools path and import our own tools
sys.path.insert(0, '../tools')

from const import ROOT_DIR, DATA_DIR
from utils import fig
from generateToyDataset import DatasetGenerator

class Experiment(object):
    def __init__(self, dataset_name, num_samples=1000, ratio_of_missing_values=.2, imbalance_ratio=.5, num_samples_gt=2000, verbosity=1, random_state=47):

        # Dataset used
        self.dataset = DatasetGenerator(name=dataset_name, 
                                        num_samples=num_samples, 
                                        ratio_of_missing_values=ratio_of_missing_values, 
                                        imbalance_ratio=imbalance_ratio, 
                                        num_samples_gt=num_samples_gt, 
                                        verbosity=verbosity, 
                                        random_state=random_state)

        # Set definitions attributes (also used for log purposes)
        self.dataset_name = dataset_name
        
        # Hyperparameters
        self.ratio_of_missing_values = ratio_of_missing_values
        self.imbalance_ratio = imbalance_ratio
        self.missingness_mechanism = None
        self.allow_missing_both_coordinates = None
        self.missing_first_quarter = None
        self.ratio_missing_per_class = None


        # Create experiment folder
        self.experiment_number, self.experiment_path, self.json_path = self._init_experiment_path()
        self.description = '({} Dataset name: {}\n'.format(self.experiment_number, self.dataset_name)


        # Define colors, level of verbosity, and random_state
        self.cmap = sns.color_palette(plt.get_cmap('tab20')(np.arange(0,2)))
        self.verbosity = verbosity 
        self.random_state = random_state

        # Initial saving of the experiment
        self.save_experiment()


    

    def retrieve_experiment(self, experiment_number=None):
        """
            This functions aims at retrieving the best model from all the experiments. 
            You can either predefince the experiment number and the epoch, or look over all the losses of all experiments and pick the model having the best performances.
            
            /!\ Not implemented yet  
        """
        path = os.path.join(DATA_DIR,  'experiments', self.dataset_name, str(experiment_number), 'experiment_log.json')

        if os.path.isfile(path):

            with open(path) as json_file:

                # Load data
                data = json.load(json_file)
                
                # Load attributes
                self._load_attributes(data)

            print("Loaded previous experiment '{}'".format(path))

        else:

            print("/!\ No previous experiment found at '{}'".format(path))
        return  
    
    def save_experiment(self):
        

        #-------- Save array information ----------#
        #np.save(filename, self.fisher_vectors)


        #-------- Save json information ----------#

        # Store here the objects that cannot be saved as json objects (saved and stored separately)
        #model = self.model
        
        #del self.model

        with open(self.json_path, 'w') as outfile:
            json.dump(self, outfile, default=lambda o: o.astype(float) if type(o) == np.int64 else o.tolist() if type(o) == np.ndarray else o.__dict__)

        # Reload the object that were unsaved 
        #self.model = model

        return


    def summary(self):
        #TODO IMPLEMENT BETTER 
        for item in list(self.__dict__.keys()):
            print("  {0:40}\t {1}".format(item, self.__getattribute__(item)))
        return

    def _init_experiment_path(self):
        """
            This method create the experiment path and folders associated with experiments. 
            It creates into the DATA_DIR location - usually "*/data/ - several objects (here is an exemple for the autism project):

                data/
                ├── experiments/
                │   ├── README.md
                │   └── 0
                │   │   ├── experiments_log.json
                │   │   ├── model
                |   |   |     ├── model.gz
                │   │   └── distributions
                |   |   |     ├── hat_f.npy
                |   |   |     ├── hat_f_1.npy
                |   |   |     ├── hat_f_2.npy
                └── *Whatever you have here*



            You have to figure out: 
                - The name of the different sub-folders contained in each experiments (model (as in the example), fisher_vectors, images, etc.)
                - The attributes of this classes which cannot be simply saved/loaded in json files. Those will be handled separately.

        """
        
        # Create experiment folder if not already created
        if not os.path.isdir(os.path.join(DATA_DIR, 'experiments')):
            os.mkdir(os.path.join(DATA_DIR, 'experiments'))
            
        # Create dataset experiment folder  if not already created
        if not os.path.isdir(os.path.join(DATA_DIR, 'experiments', self.dataset_name)):
            os.mkdir(os.path.join(DATA_DIR, 'experiments', self.dataset_name))
            os.mkdir(os.path.join(DATA_DIR, 'experiments', self.dataset_name,'0'))

        # Looking for the number of the new experiment number
        experiment_number = np.max([int(os.path.basename(path)) for path in glob(os.path.join(DATA_DIR, 'experiments', self.dataset_name, '*'))])+1

        experiment_path = os.path.join(DATA_DIR, 'experiments', self.dataset_name, str(experiment_number))
        print('Doing experiment {}!'.format(experiment_number))

        # Create experiment folder 
        os.mkdir(experiment_path)

        # Create sub-folders associated to the project
        #os.mkdir(os.path.join(experiment_path, 'disributions'))

        # Create json path
        json_path = os.path.join(experiment_path, 'experiment_log.json')

        return experiment_number, experiment_path, json_path

    def _load_attributes(self, data):

        for key, value in data.items():
            setattr(self, key, value)

