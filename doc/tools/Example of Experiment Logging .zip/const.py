import os

ROOT_DIR = '/Users/samperochon/Duke/notes_on_stats/doc/'
DATA_DIR = '/Users/samperochon/Duke/notes_on_stats/doc/data'